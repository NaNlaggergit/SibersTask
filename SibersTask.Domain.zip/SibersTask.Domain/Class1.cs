﻿namespace SibersTask.Domain
{
    public class Class1
    {

    }
}
